import os
import time
import uuid
import json
import re
import requests
from typing import List, Dict, Any

import io

from fastapi import FastAPI, UploadFile, File, Body, Response
from fastapi.responses import JSONResponse, FileResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

# ==================================================================
# 네이버 클로바 OCR 설정
#  - CLOVA_API_URL : APIGW Invoke URL (General OCR 도메인)
#  - CLOVA_SECRET_KEY : Secret Key
# ==================================================================
CLOVA_API_URL = os.getenv("CLOVA_API_URL") or "url입력"
CLOVA_SECRET_KEY = os.getenv("CLOVA_SECRET_KEY") or "키입력"
app = FastAPI(title="Naver Clova OCR Demo")

# 정적 파일(프론트) 서빙
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def root():
    # / 로 접속해도 정적 라우트(/static/...) 아래에서 로딩되도록 리다이렉트
    return RedirectResponse(url="/static/index.html")

@app.get('/favicon.ico')
def favicon():
    # 파비콘 요청 404 방지 (없어도 기능엔 영향 없음)
    return FileResponse("static/favicon.ico") if os.path.exists("static/favicon.ico") else Response(status_code=204)


def _clova_vertices_to_bbox(vertices: List[Dict[str, Any]]):
    xs = [v.get("x", 0) for v in vertices] if vertices else []
    ys = [v.get("y", 0) for v in vertices] if vertices else []
    if not xs or not ys:
        return {"x": 0, "y": 0, "w": 0, "h": 0}

    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    return {"x": int(min_x), "y": int(min_y), "w": int(max_x - min_x), "h": int(max_y - min_y)}

@app.post("/ocr")
async def ocr(file: UploadFile = File(...)):
    if not CLOVA_API_URL or not CLOVA_SECRET_KEY:
        return JSONResponse(
            {"error": "CLOVA_API_URL / CLOVA_SECRET_KEY가 비어있습니다. 환경변수를 설정하거나 server_clova.py 상단에 직접 입력하세요."},
            status_code=500
        )

    content = await file.read()
    filename = file.filename or "image.png"
    ext = filename.split(".")[-1].lower()
    if ext not in ["jpg", "jpeg", "png", "pdf", "tiff"]:
        ext = "png"

    request_json = {
        "images": [{"format": ext, "name": "cell"}],
        "requestId": str(uuid.uuid4()),
        "version": "V2",
        "timestamp": int(round(time.time() * 1000)),
    }

    headers = {"X-OCR-SECRET": CLOVA_SECRET_KEY}

    files = [("file", (filename, content, file.content_type or "application/octet-stream"))]
    data = {"message": json.dumps(request_json).encode("UTF-8")}

    try:
        resp = requests.post(CLOVA_API_URL, headers=headers, data=data, files=files, timeout=30)
        if resp.status_code != 200:
            return JSONResponse(
                {"error": f"Clova API Error: {resp.status_code}", "detail": resp.text},
                status_code=500
            )

        res_json = resp.json()

        items = []
        full_text_list = []

        images_res = res_json.get("images", [])
        if images_res:
            fields = images_res[0].get("fields", [])
            for field in fields:
                text = field.get("inferText", "") or ""
                conf = field.get("inferConfidence", 0.0) or 0.0
                poly = (field.get("boundingPoly") or {})
                vertices = poly.get("vertices", []) or []
                bbox = _clova_vertices_to_bbox(vertices)

                items.append({"text": text, "bbox": bbox, "confidence": float(conf)})
                if text:
                    full_text_list.append(text)

        full_text = " ".join(full_text_list).strip()

        return {"filename": filename, "full_text": full_text, "items": items}

    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/export_xlsx")
async def export_xlsx(payload: Dict[str, Any] = Body(...)):
    """sheet.html에서 전달한 표(값/병합/기본 스타일)를 .xlsx로 만들어 내려줍니다."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
        from openpyxl.utils import get_column_letter
    except Exception:
        return JSONResponse(
            {"detail": "openpyxl이 설치되어 있지 않습니다. (pip install openpyxl)"},
            status_code=500,
        )

    def norm_rgb(hex_color: str | None) -> str | None:
        if not hex_color:
            return None
        s = str(hex_color).strip()
        if not s:
            return None
        if s.startswith("#"):
            s = s[1:]
        if len(s) == 6:
            return "FF" + s.upper()
        if len(s) == 8:
            return s.upper()
        return None

    def side_from(d: Dict[str, Any] | None) -> Side | None:
        if not d:
            return None
        style = (d.get("style") or "thin").lower()
        color = norm_rgb(d.get("color"))
        try:
            return Side(style=style, color=color) if color else Side(style=style)
        except Exception:
            return Side(style="thin")

    wb = Workbook()
    ws = wb.active
    ws.title = str(payload.get("sheet_name") or "Sheet1")[:31]

    # column widths
    for i, w in enumerate(payload.get("col_widths") or [], start=1):
        try:
            if w is None:
                continue
            ws.column_dimensions[get_column_letter(i)].width = float(w)
        except Exception:
            continue

    # row heights (points)
    for i, h in enumerate(payload.get("row_heights") or [], start=1):
        try:
            if h is None:
                continue
            ws.row_dimensions[i].height = float(h)
        except Exception:
            continue

    # merges first (style/value는 좌상단 셀만)
    for m in payload.get("merges") or []:
        try:
            ws.merge_cells(
                start_row=int(m["r1"]),
                start_column=int(m["c1"]),
                end_row=int(m["r2"]),
                end_column=int(m["c2"]),
            )
        except Exception:
            continue

    # cells
    for cell in payload.get("cells") or []:
        try:
            r = int(cell.get("r"))
            c = int(cell.get("c"))
        except Exception:
            continue

        v = cell.get("v")
        ws_cell = ws.cell(row=r, column=c, value=v)

        s = cell.get("s") or {}

        # font
        f = s.get("font") or {}
        font_color = norm_rgb(f.get("color"))
        try:
            ws_cell.font = Font(
                name=f.get("name") or None,
                size=float(f.get("size")) if f.get("size") is not None else None,
                bold=bool(f.get("bold")) if f.get("bold") is not None else None,
                italic=bool(f.get("italic")) if f.get("italic") is not None else None,
                color=font_color,
            )
        except Exception:
            pass

        # fill
        fill_hex = norm_rgb(s.get("fill"))
        if fill_hex:
            try:
                ws_cell.fill = PatternFill(fill_type="solid", fgColor=fill_hex)
            except Exception:
                pass

        # alignment
        a = s.get("alignment") or {}
        h = a.get("horizontal")
        v_ = a.get("vertical")
        if v_ == "middle":
            v_ = "center"
        try:
            ws_cell.alignment = Alignment(
                horizontal=h if h in {"left", "center", "right", "fill", "justify", "distributed"} else None,
                vertical=v_ if v_ in {"top", "center", "bottom", "justify", "distributed"} else None,
                wrap_text=bool(a.get("wrap")) if a.get("wrap") is not None else None,
            )
        except Exception:
            pass

        # border
        b = s.get("border") or {}
        left = side_from(b.get("left"))
        right = side_from(b.get("right"))
        top = side_from(b.get("top"))
        bottom = side_from(b.get("bottom"))
        if any([left, right, top, bottom]):
            try:
                ws_cell.border = Border(left=left or Side(), right=right or Side(), top=top or Side(), bottom=bottom or Side())
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Post-process borders (requested rules)
    #  - A1:X4    : no borders
    #  - A5:X57   : ensure all cells have borders (fill missing only)
    #  - A25:X25, A48:X48, A52:X52 : remove outer left/right borders
    # ------------------------------------------------------------------
    try:
        ws.sheet_view.showGridLines = False

        THIN = Side(style="thin")
        NONE = Side(style=None)

        def _keep_or_thin(side: Side | None) -> Side:
            if side is None or getattr(side, "style", None) is None:
                return THIN
            return side

        def _clone_border(b: Border, *, left=None, right=None, top=None, bottom=None) -> Border:
            # Preserve all other border attributes; override only provided sides
            return Border(
                left=b.left if left is None else left,
                right=b.right if right is None else right,
                top=b.top if top is None else top,
                bottom=b.bottom if bottom is None else bottom,
                diagonal=b.diagonal,
                diagonal_direction=b.diagonal_direction,
                outline=b.outline,
                vertical=b.vertical,
                horizontal=b.horizontal,
                diagonalUp=b.diagonalUp,
                diagonalDown=b.diagonalDown,
                start=b.start,
                end=b.end,
            )

        def _safe_set_border(rr: int, cc: int, border_obj: Border):
            try:
                ws.cell(row=rr, column=cc).border = border_obj
            except Exception:
                # Merged cells or read-only style objects can throw; skip them
                pass

        # 1) Header area: clear borders
        for rr in range(1, 4 + 1):
            for cc in range(1, 24 + 1):
                _safe_set_border(rr, cc, Border())

        # 2) Main table: ensure borders (thin) exist on all sides where missing
        for rr in range(5, 57 + 1):
            for cc in range(1, 24 + 1):
                try:
                    cell_obj = ws.cell(row=rr, column=cc)
                    b0 = cell_obj.border or Border()
                    nb = _clone_border(
                        b0,
                        left=_keep_or_thin(b0.left),
                        right=_keep_or_thin(b0.right),
                        top=_keep_or_thin(b0.top),
                        bottom=_keep_or_thin(b0.bottom),
                    )
                    cell_obj.border = nb
                except Exception:
                    pass

        # 3) Special rows: remove ONLY the outer left/right borders (A and X)
        for rr in (25, 48, 52):
            try:
                cA = ws.cell(row=rr, column=1)
                bA = cA.border or Border()
                cA.border = _clone_border(bA, left=NONE)
            except Exception:
                pass
            try:
                cX = ws.cell(row=rr, column=24)
                bX = cX.border or Border()
                cX.border = _clone_border(bX, right=NONE)
            except Exception:
                pass

        # 4) Block N27:X47: keep only outer border (no internal grid)
        for rr in range(27, 48):
            for cc in range(14, 25):
                cell = ws.cell(row=rr, column=cc)
                b0 = cell.border or Border()
                cell.border = _clone_border(
                    b0,
                    left=THIN if cc == 14 else NONE,
                    right=THIN if cc == 24 else NONE,
                    top=THIN if rr == 27 else NONE,
                    bottom=THIN if rr == 47 else NONE,
                )

        # 5) Remove right-border boundaries for specific ranges
        #    (also clear the neighbor's left border so the vertical line disappears)
        def _col_to_idx(col: str) -> int:
            col = col.upper()
            n = 0
            for ch in col:
                if not ('A' <= ch <= 'Z'):
                    break
                n = n * 26 + (ord(ch) - 64)
            return n

        def _parse_addr(a: str):
            a = a.strip().upper()
            m = re.match(r'^([A-Z]+)(\d+)$', a)
            if not m:
                raise ValueError(f'bad addr: {a}')
            return _col_to_idx(m.group(1)), int(m.group(2))

        def _iter_cells(spec: str):
            spec = spec.strip().upper()
            if ':' in spec:
                a1, a2 = spec.split(':', 1)
            else:
                a1 = a2 = spec
            c1, r1 = _parse_addr(a1)
            c2, r2 = _parse_addr(a2)
            if c1 > c2:
                c1, c2 = c2, c1
            if r1 > r2:
                r1, r2 = r2, r1
            for r_ in range(r1, r2 + 1):
                for c_ in range(c1, c2 + 1):
                    yield r_, c_

        def _remove_right_boundary(r_: int, c_: int):
            if c_ < 1 or c_ > 24:
                return
            cell = ws.cell(row=r_, column=c_)
            b0 = cell.border or Border()
            cell.border = _clone_border(b0, right=NONE)
            if c_ + 1 <= 24:
                nb = ws.cell(row=r_, column=c_ + 1)
                b1 = nb.border or Border()
                nb.border = _clone_border(b1, left=NONE)

        for spec in [
            'B53:G53',
            'J53:N53',
            'P53:W53',
            'B54',
            'B55',
            'C55:I55',
            'J55:O55',
            'P55:Q55',
            'R55',
            'S55:T55',
            'U55',
            'V55:W55',
            'B56:D56',
            'E56:G56',
            'H56:L56',
            'O56:Q56',
            'R56:S56',
            'T56:W56',
        ]:
            for r_, c_ in _iter_cells(spec):
                _remove_right_boundary(r_, c_)


    except Exception as _e:
        print(f"[export_xlsx] post-process borders failed: {_e}")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    content = buf.getvalue()
    headers = {"Content-Disposition": 'attachment; filename="sheet.xlsx"'}
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=headers,
    )
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
