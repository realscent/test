# Table Snapper + Clova OCR bundle

## Run
1) Install Python deps:
   pip install fastapi uvicorn python-multipart requests pillow

2) Edit server_clova.py and set:
   - CLOVA_API_URL
   - CLOVA_SECRET_KEY
   (or set them as environment variables)

3) Start server:
   python server_clova.py

4) Open:
   http://127.0.0.1:8000
